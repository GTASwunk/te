# ClearStatus changelog #

### Build date: 2019-05-16 20:00 ###

<hr />

## Version 2.0.0 (2019-05-16) ##

**New**
- Added support for grouping systems and displaying them under collapsible headers
- Added changelog

**Changes**
- Invoke npm install explicitely on Netlify builds, Netlify caching does not handle postCSS

## Version 1.0.0 (2019-05-14) ##

