---
title: "Netlify config file"
date: 2019-04-11
type: page
outputs:
  - netlifyyaml
---
